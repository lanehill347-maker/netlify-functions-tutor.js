// LearnLoop V3 — Netlify serverless AI tutor.
// Keep OPENAI_API_KEY in Netlify's environment variables; never put it in browser code.
const WINDOW_MS = 60_000;
const LIMIT = 12;
const hits = new Map(); // Best-effort per-function-instance limit, not a global distributed limiter.

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  };
  const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });

  if (event.httpMethod !== 'POST') {
    return { ...reply(405, { error: 'Use POST to ask the tutor.' }), headers: { ...headers, Allow: 'POST' } };
  }
  if (!process.env.OPENAI_API_KEY) {
    return reply(503, { error: 'AI tutor is not configured yet. Add OPENAI_API_KEY in Netlify environment variables.' });
  }

  // Best-effort protection against accidental rapid requests. For a public launch,
  // add a shared/distributed rate limiter and usage limits at your provider.
  const ip = event.headers?.['x-nf-client-connection-ip'] || event.headers?.['x-forwarded-for']?.split(',')[0]?.trim() || 'unknown';
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= LIMIT) {
    return reply(429, { error: 'Too many questions in a short time. Please wait a minute and try again.' });
  }
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 2000) {
    for (const [key, times] of hits) {
      if (!times.some((t) => now - t < WINDOW_MS)) hits.delete(key);
    }
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return reply(400, { error: 'Invalid request body. Please try again.' });
  }
  const { question, level = 'Beginner', format = 'Explain simply' } = body || {};
  if (typeof question !== 'string' || !question.trim() || question.length > 2000) {
    return reply(400, { error: 'Enter a question of up to 2,000 characters.' });
  }
  const levels = ['Beginner', 'Intermediate', 'Advanced'];
  const formats = ['Explain simply', 'Step by step', 'Give an example', 'Quiz me'];
  const chosenLevel = levels.includes(level) ? level : 'Beginner';
  const chosenFormat = formats.includes(format) ? format : 'Explain simply';
  const instructions = `You are LearnLoop, a patient, inclusive tutor helping people learn. Explain at a ${chosenLevel.toLowerCase()} level. Format preference: ${chosenFormat}. Be accurate, kind, and clear. Define jargon. For quiz mode, ask one question and wait for the learner's answer. For other modes, include a short explanation and one practical example when useful. If uncertain, say so and suggest how to verify. Do not claim to be a human. Avoid asking for personal data.`;

  try {
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        instructions,
        input: question.trim(),
        max_output_tokens: 800,
      }),
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error('AI provider error:', upstream.status, data.error?.type || 'unknown');
      return reply(502, { error: 'The AI service could not answer. Check the API key, model access, and API billing.' });
    }
    const answer = (data.output || [])
      .flatMap((item) => item.content || [])
      .filter((content) => content.type === 'output_text')
      .map((content) => content.text)
      .join('\n')
      .trim();
    if (!answer) return reply(502, { error: 'The tutor returned an empty answer. Please try again.' });
    return reply(200, { answer });
  } catch (error) {
    console.error('Tutor request failed:', error.message);
    return reply(502, { error: 'Could not reach the AI service. Please try again.' });
  }
};
