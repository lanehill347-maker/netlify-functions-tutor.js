LEARNLOOP V3 — NETLIFY + SECURE AI TUTOR

WHAT'S INCLUDED
- index.html: LearnLoop website, lessons, quizzes, dark mode, saved progress, and AI tutor UI
- netlify/functions/tutor.js: server-side function that calls the OpenAI Responses API
- netlify.toml: tells Netlify where the site and function live and routes /api/tutor to it

DEPLOY (RECOMMENDED: GITHUB + NETLIFY)
1. Extract this ZIP.
2. Create a new GitHub repository at https://github.com/new. A private repository is fine.
3. Upload the CONTENTS of the learnloop-site folder to the repository root. Ensure index.html and netlify.toml are at the root and the netlify/functions/tutor.js path exists.
4. In Netlify, choose Add new site > Import an existing project, connect GitHub, and select this repository.
5. Build settings should be: Build command blank (or none); Publish directory . ; Functions directory netlify/functions. The included netlify.toml sets these.
6. Before testing the AI, open Site configuration (or Project configuration) > Environment variables and add:
   OPENAI_API_KEY = your secret API key
   OPENAI_MODEL = gpt-4.1-mini (optional; default is gpt-4.1-mini)
7. Save the variables, then trigger a new deploy so the function receives them.
8. Open the Netlify site URL and ask the AI tutor a question.

IMPORTANT SECURITY AND COST NOTES
- Never put the OpenAI key in index.html, client-side JavaScript, GitHub, or any public file.
- OpenAI API billing is separate from a ChatGPT subscription. Set provider usage limits/budgets and monitor usage.
- The included in-memory rate limiter is best-effort per function instance; serverless instances can scale/restart. Before public promotion, add a shared rate limiter (for example, a Redis/Upstash-backed limiter), usage monitoring, and a privacy notice.
- Do not collect children's or other learners' sensitive personal information. Explain to users what is sent to the AI provider.
- The function only accepts POST and limits questions to 2,000 characters. It does not expose the secret key to the browser.

LOCAL TESTING
Netlify Functions need Netlify's local runtime. Install Node.js 18+ and the Netlify CLI, set OPENAI_API_KEY in your shell environment, then run `netlify dev` from this folder. Do not commit your key.
